from .models2 import QuantizationLayer
# This will be removed later. Kept for compatibility only
from .loader2 import Loader
from .loss import cross_entropy_loss_and_accuracy